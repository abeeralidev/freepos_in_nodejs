__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSScrollNav;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

/*
 * HSScrollNav Plugin
 * @version: 3.0.0 (Mon, 08 Jun 2020)
 * @requires: jQuery v3.0 or later, Bootstrap 4.5 or later
 * @author: HtmlStream
 * @event-namespace: .HSScrollNav
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2020 Htmlstream
 */
var HSScrollNav = /*#__PURE__*/ function() {
    function HSScrollNav(element, config) {
        _classCallCheck(this, HSScrollNav);

        this.element = element;
        this.defaults = {
            topLevelComponent: 'html, body',
            target: null,
            duration: 400,
            offset: 0,
            easing: 'linear',
            beforeScroll: null,
            afterScroll: null,
            breakpoint: 769
        };
        this.config = config;
    }

    _createClass(HSScrollNav, [{
        key: "init",
        value: function init() {
            var self = this,
                element = self.element,
                dataSettings = $(element).attr('data-hs-scroll-nav-options') ? JSON.parse($(element).attr('data-hs-scroll-nav-options')) : {};
            self.config = Object.assign({}, self.defaults, dataSettings, self.config);

            self._bindEvents();

            $(element).scrollspy(self.config);
        }
    }, {
        key: "_bindEvents",
        value: function _bindEvents() {
            var self = this;
            $(self.config.target).on('click', 'a:not([href="#"]):not([href="#0"])', function(e) {
                var hash, offsetTop;
                e.preventDefault();

                if ($.isFunction(self.config.beforeScroll)) {
                    self.config.beforeScroll();
                }

                if (this.hash !== '' && $(this.hash).length) {
                    hash = this.hash; //offsetTop = ($(hash).offset().top + 2) - self.config.offset;

                    offsetTop = self.config.topLevelComponent == 'html, body' ? $(hash).offset().top + 2 - self.config.offset : $(self.config.topLevelComponent).scrollTop() - $(self.config.topLevelComponent).offset().top + ($(hash).offset().top + 2 - self.config.offset); // Smooth scroll

                    $(self.config.topLevelComponent).animate({
                        scrollTop: offsetTop
                    }, {
                        duration: self.config.duration,
                        easing: self.config.easing,
                        complete: function complete() {
                            if (history.replaceState) {
                                history.replaceState(null, null, hash);
                            }

                            if ($.isFunction(self.config.afterScroll)) {
                                self.config.afterScroll();
                            }
                        }
                    });
                    return false;
                }
            });
        }
    }]);

    return HSScrollNav;
}();