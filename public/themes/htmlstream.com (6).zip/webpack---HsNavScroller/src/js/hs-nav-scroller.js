__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HsNavScroller;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

var HsNavScroller = /*#__PURE__*/ function() {
    function HsNavScroller(elem, settings) {
        _classCallCheck(this, HsNavScroller);

        this.elem = elem;
        this.defaults = {
            type: 'horizontal',
            target: '.active',
            offset: 0,
            delay: 20
        };
        this.settings = settings;
    }

    _createClass(HsNavScroller, [{
        key: "init",
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-nav-scroller-options') ? JSON.parse($el.attr('data-hs-nav-scroller-options')) : {},
                options = $.extend(true, context.defaults, dataSettings, context.settings);

            if (options.type == 'vertical') {
                $($el).animate({
                    scrollTop: $($el).find(options.target).position().top - options.offset
                }, options.delay);
            } else if (options.type == 'horizontal') {
                var nav = $($el).find('.nav').first(),
                    prev = $($el).find('.hs-nav-scroller-arrow-prev').first(),
                    next = $($el).find('.hs-nav-scroller-arrow-next').first(),
                    activeElementLeftPosition = nav.find(options.target).position().left,
                    scrollMaxLeft = (nav[0].scrollWidth.toFixed() - nav.outerWidth()).toFixed(),
                    scrollPosition = nav.scrollLeft();

                if (scrollPosition <= 0) {
                    prev.fadeOut(0);
                }

                if (scrollMaxLeft <= 0) {
                    next.fadeOut(0);
                }

                $(window).on('load resize', function() {
                    var scrollMaxLeft = parseInt(nav[0].scrollWidth.toFixed()) - parseInt(nav.outerWidth().toFixed()),
                        scrollPosition = nav.scrollLeft();

                    if (scrollPosition <= 0) {
                        prev.fadeOut(0);
                    } else {
                        prev.fadeIn(0);
                    }

                    if (scrollMaxLeft <= 0) {
                        next.fadeOut(0);
                    } else {
                        next.fadeIn(0);
                    }
                });

                if (activeElementLeftPosition > nav.width() / 2) {
                    nav.animate({
                        scrollLeft: activeElementLeftPosition - options.offset - prev.width()
                    }, options.delay);
                }

                next.click(function() {
                    var scrollPosition = nav.scrollLeft();
                    nav.animate({
                        scrollLeft: scrollPosition + nav.outerWidth() - next.width()
                    }, options.delay);
                });
                prev.click(function() {
                    var scrollPosition = nav.scrollLeft();
                    nav.animate({
                        scrollLeft: scrollPosition - nav.outerWidth() + prev.width()
                    }, options.delay);
                });
                nav.scroll(function() {
                    var scrollMaxLeft = (nav[0].scrollWidth.toFixed() - nav.outerWidth()).toFixed(),
                        scrollPosition = nav.scrollLeft(); // Hide or Show Back Arrow

                    if (scrollPosition <= 0) {
                        prev.fadeOut(0);
                    } else {
                        prev.fadeIn(0);
                    } // Hide or Show Next Arrow


                    if (scrollPosition >= scrollMaxLeft) {
                        next.fadeOut(0);
                    } else {
                        next.fadeIn(0);
                    }
                });
            }
        }
    }]);

    return HsNavScroller;
}();