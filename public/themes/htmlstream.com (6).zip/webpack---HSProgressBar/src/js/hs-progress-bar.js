Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var HSProgressBar = function() {
    function HSProgressBar(elem, settings) {
        _classCallCheck(this, HSProgressBar);

        this.elem = elem;
        this.defaults = {
            bounds: -100,
            debounce: 10,
            duration: 1000,
            isRtl: false,
            direction: 'horizontal',
            useProgressElement: false,
            indicatorSelector: '.hs-progress-bar-indicator',

            afterUpdate: function afterUpdate() {}
        };
        this.settings = settings;
    }

    _createClass(HSProgressBar, [{
        key: 'init',
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-progress-bar-options') ? JSON.parse($el.attr('data-hs-progress-bar-options')) : {};
            var options = $.extend(true, context.defaults, dataSettings, context.settings);

            options.init = function() {
                if (options.direction === 'horizontal') {
                    context._buildHorizontalProgressBar($el, options);
                } else {
                    context._buildVerticalProgressBar($el, options);
                }
            };
            options.elements = function() {
                return $el;
            };
            options.appear = function(el) {
                if (options.direction === 'horizontal') {
                    $(el).find(options.indicatorSelector).stop().animate({
                        width: $(el).data('value') + '%'
                    }, {
                        duration: options.duration,
                        complete: function complete() {
                            options.afterUpdate();
                        }
                    });
                } else {
                    $(el).find(options.indicatorSelector).stop().animate({
                        height: $(el).data('value') + '%'
                    }, {
                        duration: options.duration,
                        complete: function complete() {
                            options.afterUpdate();
                        }
                    });
                }
            };

            appear(options);
        }
    }, {
        key: '_buildHorizontalProgressBar',
        value: function _buildHorizontalProgressBar(el, params) {
            var options = params;

            if (options.useProgressElement) {
                el.attr('data-value', el.attr('value'));
                el.attr('value', 0);
            } else {
                el.attr('data-value', el.find(options.indicatorSelector).length ? Math.round(el.find(options.indicatorSelector).outerWidth() / el.outerWidth() * 100) : 0);
                el.find(options.indicatorSelector).css({
                    width: 0
                });
            }
        }
    }, {
        key: '_buildVerticalProgressBar',
        value: function _buildVerticalProgressBar(el, params) {
            var options = params;

            if (!el.find(options.indicatorSelector).length) {
                return;
            }

            el.attr('data-value', parseInt(el.find(options.indicatorSelector).css('height'), 10) / el.find(options.indicatorSelector).parent().outerHeight() * 100);
            el.find(options.indicatorSelector).css({
                height: 0
            });
        }
    }]);

    return HSProgressBar;
}();

exports.default = HSProgressBar;