__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSStepForm;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

/*
 * HSStepForm Plugin
 * @version: 2.0.0 (Mon, 25 Nov 2019)
 * @requires: jQuery v3.0 or later
 * @author: HtmlStream
 * @event-namespace: .HSStepForm
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */
var HSStepForm = /*#__PURE__*/ function() {
    function HSStepForm(elem, settings) {
        _classCallCheck(this, HSStepForm);

        this.elem = elem;
        this.defaults = {
            progressSelector: null,
            progressItems: null,
            stepsSelector: null,
            stepsItems: null,
            stepsActiveItem: null,
            nextSelector: '[data-hs-step-form-next-options]',
            prevSelector: '[data-hs-step-form-prev-options]',
            endSelector: null,
            isValidate: false,
            classMap: {
                active: 'active',
                checked: 'is-valid',
                error: 'is-invalid',
                required: 'js-step-required',
                focus: 'focus'
            },
            finish: function finish() {},
            onNextStep: function onNextStep() {},
            onPrevStep: function onPrevStep() {}
        };
        this.settings = settings;
    }

    _createClass(HSStepForm, [{
        key: "init",
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-step-form-options') ? JSON.parse($el.attr('data-hs-step-form-options')) : {};
            var options = $.extend(true, context.defaults, dataSettings, context.settings);
            options.progressItems = $(options.progressSelector).find('> *');
            options.stepsItems = $(options.stepsSelector).find('> *');
            options.stepsActiveItem = $(options.stepsSelector).find("> .".concat(options.classMap.active));

            context._prepareObject($el, options);

            $el.find(options.nextSelector).on('click', function() {
                context._nextClickEvents($el, options, $(this));
            });
            $el.find(options.prevSelector).on('click', function() {
                context._prevClickEvents($el, options, $(this));
            });
            $el.find(options.endSelector).on('click', function() {
                context._endClickEvents($el, options, $(this));
            });
        }
    }, {
        key: "_prepareObject",
        value: function _prepareObject(el, params) {
            var options = params;
            options.stepsItems.not(".".concat(options.classMap.active)).hide();
            options.progressItems.eq(options.stepsActiveItem.index()).addClass(options.classMap.active).addClass(options.classMap.focus);
        }
    }, {
        key: "_endClickEvents",
        value: function _endClickEvents(el, params) {
            var options = params;
            return params.finish();
        }
    }, {
        key: "_nextClickEvents",
        value: function _nextClickEvents(el, params, nextEl) {
            var nextDataSettings = nextEl.attr('data-hs-step-form-next-options') ? JSON.parse(nextEl.attr('data-hs-step-form-next-options')) : {};
            var options = params,
                nextItemDefaults = {
                    targetSelector: null
                },
                nextItemOptions = $.extend(true, nextItemDefaults, nextDataSettings);

            for (var i = 0; i < options.progressItems.length; i++) {
                if (typeof $(window).validate !== 'undefined' && options.isValidate) {
                    if ($(nextItemOptions.targetSelector).index() > i) {
                        $(options.progressItems[i]).addClass(options.classMap.error);
                        var requiredSelector = $(options.progressItems[i]).find(options.nextSelector).attr('data-hs-step-form-next-options');
                        options.stepsItems.hide().removeClass(options.classMap.active);
                        $(JSON.parse(requiredSelector).targetSelector).show().addClass(options.classMap.active);

                        if (!el.valid()) {
                            return false;
                        } else {
                            $(options.progressItems[i]).removeClass(options.classMap.error);
                        }
                    }

                    if ($(nextItemOptions.targetSelector).index() > i && options.isValidate) {
                        $(options.progressItems[i]).addClass(options.classMap.checked);
                    }
                } else {
                    if ($(nextItemOptions.targetSelector).index() > i && options.isValidate) {
                        $(options.progressItems[i]).addClass(options.classMap.checked);
                    }

                    if ($(nextItemOptions.targetSelector).index() > i && !options.isValidate) {
                        $(options.progressItems[i]).addClass(options.classMap.active);
                    }
                }
            }

            options.progressItems.removeClass(options.classMap.active).removeClass(options.classMap.focus);
            options.progressItems.eq($(nextItemOptions.targetSelector).index()).addClass(options.classMap.active).addClass(options.classMap.focus);
            options.stepsItems.hide().removeClass(options.classMap.active);
            $(nextItemOptions.targetSelector).fadeIn(400).addClass(options.classMap.active);
            return options.onNextStep();
        }
    }, {
        key: "_prevClickEvents",
        value: function _prevClickEvents(el, params, prevEl) {
            var options = params,
                prevItemDefaults = {
                    targetSelector: null
                };
            var prevDataSettings = prevEl.attr('data-hs-step-form-prev-options') ? JSON.parse(prevEl.attr('data-hs-step-form-prev-options')) : {};
            var prevItemOptions = $.extend(true, prevItemDefaults, prevDataSettings);

            for (var i = 0; i < options.progressItems.length; i++) {
                if (typeof $(window).validate !== 'undefined' && options.isValidate) {
                    if ($(prevItemOptions.targetSelector).index() > i) {
                        $(options.progressItems[i]).addClass(options.classMap.error);
                        var requiredSelector = $(options.progressItems[i]).find(options.nextSelector).attr('data-hs-step-form-next-options');
                        options.stepsItems.hide().removeClass(options.classMap.active);
                        $(JSON.parse(requiredSelector).targetSelector).show().addClass(options.classMap.active);

                        if (!el.valid()) {
                            return false;
                        } else {
                            $(options.progressItems[i]).removeClass(options.classMap.error);
                        }
                    }

                    if ($(prevItemOptions.targetSelector).index() > i && options.isValidate) {
                        $(options.progressItems[i]).addClass(options.classMap.checked);
                    }
                } else {
                    if ($(prevItemOptions.targetSelector).index() > i && options.isValidate) {
                        $(options.progressItems[i]).addClass(options.classMap.checked);
                    }

                    if ($(prevItemOptions.targetSelector).index() > i && !options.isValidate) {
                        $(options.progressItems[i]).addClass(options.classMap.active);
                    }
                }
            }

            options.progressItems.removeClass(options.classMap.active).removeClass(options.classMap.focus);
            options.progressItems.eq($(prevItemOptions.targetSelector).index()).addClass(options.classMap.active).addClass(options.classMap.focus);
            options.stepsItems.hide().removeClass(options.classMap.active);
            $(prevItemOptions.targetSelector).fadeIn(400).addClass(options.classMap.active);
            return options.onPrevStep();
        }
    }]);

    return HSStepForm;
}();