__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSGoTo;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

var HSGoTo = /*#__PURE__*/ function() {
    function HSGoTo(elem, settings) {
        _classCallCheck(this, HSGoTo);

        this.elem = elem;
        this.defaults = {
            pageContainerSelector: 'html, body',
            targetSelector: null,
            compensationSelector: null,
            animationInit: 'animated',
            animationIn: 'fadeInUp',
            animationOut: 'fadeOutDown',
            duration: 800,
            offsetTop: 0,
            position: {
                init: null,
                hide: null,
                show: null
            },
            isReferencedToOtherPage: null,
            preventEventClass: 'hs-go-to-prevent-event'
        };
        this.settings = settings;
    }

    _createClass(HSGoTo, [{
        key: "init",
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-go-to-options') ? JSON.parse($el.attr('data-hs-go-to-options')) : {},
                options = Object.assign({}, context.defaults, dataSettings, context.settings);

            options.targetOffsetTop = function() {
                if ($(options.compensationSelector).length) {
                    return $(options.targetSelector) ? $(options.targetSelector).offset().top - $(options.compensationSelector).outerHeight() : 0;
                } else {
                    return $(options.targetSelector).length ? $(options.targetSelector).offset().top : 0;
                }
            };

            context._prepareObject($el, options); // Set Position


            if (options.position) {
                context._setPosition($el, options.position.init);
            } // Click Events


            $el.on('click', function(e) {
                context._clickEvents($el, options, e);
            }); // Scroll Events

            if (options.animationIn && options.animationOut) {
                $(window).on('scroll', function() {
                    context._scrollEvents($el, options);
                });
            }
        }
    }, {
        key: "_prepareObject",
        value: function _prepareObject(el, params) {
            var options = params;

            if (params.animationIn && params.animationOut) {
                if (navigator.userAgent.match('MSIE 10.0;')) {
                    $('html').addClass('ie10');
                }

                el.addClass("".concat(options.animationInit, " ").concat(options.animationOut, " ").concat(options.preventEventClass));
            }
        }
    }, {
        key: "_setPosition",
        value: function _setPosition(el, params) {
            var options = params;
            el.css(options);
        }
    }, {
        key: "_clickEvents",
        value: function _clickEvents(el, params, event) {
            var options = params;

            if (!options.isReferencedToOtherPage) {
                if (event) {
                    event.preventDefault();
                }

                $(options.pageContainerSelector).stop().animate({
                    scrollTop: options.targetOffsetTop()
                }, options.duration);
            }
        }
    }, {
        key: "_scrollEvents",
        value: function _scrollEvents(el, params) {
            var options = params;
            el.css('visibility', '');

            if ($(window).scrollTop() >= options.offsetTop) {
                if (options.position.show) {
                    el.css(options.position.show);
                }

                el.removeClass(options.animationOut).addClass(options.animationIn);
            } else {
                if (options.position.hide) {
                    el.css(options.position.hide);
                }

                el.removeClass(options.animationIn).addClass(options.animationOut);
            }
        }
    }]);

    return HSGoTo;
}();