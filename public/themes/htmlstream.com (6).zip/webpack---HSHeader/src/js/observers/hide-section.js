__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSHeaderHideSectionObserver;
});
/* harmony import */
var _abstract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__( /*! ./abstract */ "./src/js/observers/abstract.js");

function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

function _possibleConstructorReturn(self, call) {
    if (call && (_typeof(call) === "object" || typeof call === "function")) {
        return call;
    }
    return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
    if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
}

function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
}

function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _setPrototypeOf(o, p);
}



var HSHeaderHideSectionObserver = /*#__PURE__*/ function(_HSAbstractObserver) {
    _inherits(HSHeaderHideSectionObserver, _HSAbstractObserver);

    function HSHeaderHideSectionObserver(element) {
        var _this;

        _classCallCheck(this, HSHeaderHideSectionObserver);

        _this = _possibleConstructorReturn(this, _getPrototypeOf(HSHeaderHideSectionObserver).call(this, element));
        _this.dataSettings = _this.element.attr('data-hs-header-options') ? JSON.parse(_this.element.attr('data-hs-header-options')) : {};
        return _this;
    }

    _createClass(HSHeaderHideSectionObserver, [{
        key: "init",
        value: function init() {
            this.offset = isFinite(this.dataSettings.fixMoment) ? this.dataSettings.fixMoment : 5;
            this.section = this.element.find('.header-section-hidden');
            this.defaultState = true;
            this.sectionHeight = this.section.length ? this.section.outerHeight() : 0;
            return this;
        }
    }, {
        key: "destroy",
        value: function destroy() {
            if (this.section.length) {
                this.element.css({
                    'margin-top': 0
                });
            }

            return this;
        }
    }, {
        key: "check",
        value: function check() {
            if (!this.section.length) return this;
            var $w = $(window),
                docScrolled = $w.scrollTop();

            if (docScrolled > this.offset && this.defaultState) {
                this.changeState();
            } else if (docScrolled <= this.offset && !this.defaultState) {
                this.toDefaultState();
            }

            return this;
        }
    }, {
        key: "changeState",
        value: function changeState() {
            var self = this;
            this.element.stop().animate({
                'margin-top': self.sectionHeight * -1 - 1 // last '-1' is a small fix

            });
            this.defaultState = !this.defaultState;
            return this;
        }
    }, {
        key: "toDefaultState",
        value: function toDefaultState() {
            this.element.stop().animate({
                'margin-top': 0
            });
            this.defaultState = !this.defaultState;
            return this;
        }
    }]);

    return HSHeaderHideSectionObserver;
}(_abstract__WEBPACK_IMPORTED_MODULE_0__["default"]);