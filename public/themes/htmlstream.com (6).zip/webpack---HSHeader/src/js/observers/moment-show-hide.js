__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSHeaderMomentShowHideObserver;
});
/* harmony import */
var _abstract__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__( /*! ./abstract */ "./src/js/observers/abstract.js");

function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

function _possibleConstructorReturn(self, call) {
    if (call && (_typeof(call) === "object" || typeof call === "function")) {
        return call;
    }
    return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
    if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
}

function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
}

function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _setPrototypeOf(o, p);
}



var HSHeaderMomentShowHideObserver = /*#__PURE__*/ function(_HSAbstractObserver) {
    _inherits(HSHeaderMomentShowHideObserver, _HSAbstractObserver);

    function HSHeaderMomentShowHideObserver(element) {
        var _this;

        _classCallCheck(this, HSHeaderMomentShowHideObserver);

        _this = _possibleConstructorReturn(this, _getPrototypeOf(HSHeaderMomentShowHideObserver).call(this, element));
        _this.dataSettings = _this.element.attr('data-hs-header-options') ? JSON.parse(_this.element.attr('data-hs-header-options')) : {};
        return _this;
    }

    _createClass(HSHeaderMomentShowHideObserver, [{
        key: "init",
        value: function init() {
            this.direction = 'down';
            this.delta = 0;
            this.defaultState = true;
            this.offset = isFinite(this.dataSettings.fixMoment) && this.dataSettings.fixMoment !== 0 ? this.dataSettings.fixMoment : 5;
            this.effect = this.dataSettings.fixEffect ? this.dataSettings.fixEffect : 'show-hide';
            return this;
        }
    }, {
        key: "destroy",
        value: function destroy() {
            this.toDefaultState();
            return this;
        }
    }, {
        key: "checkDirection",
        value: function checkDirection() {
            if ($(window).scrollTop() > this.delta) {
                this.direction = 'down';
            } else {
                this.direction = 'up';
            }

            this.delta = $(window).scrollTop();
            return this;
        }
    }, {
        key: "toDefaultState",
        value: function toDefaultState() {
            switch (this.effect) {
                case 'slide':
                    this.element.removeClass('header-moved-up');
                    break;

                case 'fade':
                    this.element.removeClass('header-faded');
                    break;

                default:
                    this.element.removeClass('header-invisible');
            }

            this.defaultState = !this.defaultState;
            return this;
        }
    }, {
        key: "changeState",
        value: function changeState() {
            switch (this.effect) {
                case 'slide':
                    this.element.addClass('header-moved-up');
                    break;

                case 'fade':
                    this.element.addClass('header-faded');
                    break;

                default:
                    this.element.addClass('header-invisible');
            }

            this.defaultState = !this.defaultState;
            return this;
        }
    }, {
        key: "check",
        value: function check() {
            var docScrolled = $(window).scrollTop();
            this.checkDirection();

            if (docScrolled >= this.offset && this.defaultState && this.direction === 'down') {
                this.changeState();
            } else if (!this.defaultState && this.direction === 'up') {
                this.toDefaultState();
            }

            return this;
        }
    }]);

    return HSHeaderMomentShowHideObserver;
}(_abstract__WEBPACK_IMPORTED_MODULE_0__["default"]);