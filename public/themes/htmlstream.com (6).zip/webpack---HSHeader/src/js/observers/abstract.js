__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSAbstractObserver;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

var HSAbstractObserver = /*#__PURE__*/ function() {
    function HSAbstractObserver(element) {
        _classCallCheck(this, HSAbstractObserver);

        this.element = element;
        this.defaultState = true;
    }

    _createClass(HSAbstractObserver, [{
        key: "reinit",
        value: function reinit() {
            this.destroy().init().check();
        }
    }]);

    return HSAbstractObserver;
}();