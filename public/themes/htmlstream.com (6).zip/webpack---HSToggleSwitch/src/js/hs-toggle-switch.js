Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();
/*
 * HSToggleSwitch Plugin
 * @version: 1.0.0 (Mon, 12 Dec 2019)
 * @requires: jQuery v3.0 or later, countup.js v2.0.4
 * @author: HtmlStream
 * @event-namespace: .HSToggleSwitch
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */

var _countup = __webpack_require__( /*! countup.js */ "./node_modules/countup.js/dist/countUp.min.js");

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var HSToggleSwitch = function() {
    function HSToggleSwitch(elem, settings) {
        _classCallCheck(this, HSToggleSwitch);

        this.elem = elem;
        this.defaults = {
            mode: 'toggle-count',
            targetSelector: undefined,
            isChecked: false,
            eventType: 'change'
        };
        this.settings = settings;
        this.params = null;
    }

    _createClass(HSToggleSwitch, [{
        key: 'init',
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-toggle-switch-options') ? JSON.parse($el.attr('data-hs-toggle-switch-options')) : {};
            var options = this.params = $.extend(true, context.defaults, dataSettings, context.settings);
            this.params.isChecked = this.elem.is(':checked');

            // Toggle Count
            if (options.mode === 'toggle-count') {
                if (options.isChecked) {
                    var $target = $(options.targetSelector);

                    options.isChecked = true;

                    $target.each(function() {
                        var $this = $(this),
                            currentDataSettings = $this.attr('data-hs-toggle-switch-item-options') ? JSON.parse($this.attr('data-hs-toggle-switch-item-options')) : {};

                        $this.text(currentDataSettings.max);
                    });
                }

                $el.on(options.eventType, function() {
                    context._toggleCount();
                });
            }
        }

        // Toggle Count

    }, {
        key: '_toggleCount',
        value: function _toggleCount() {
            var context = this,
                options = context.params;

            if (options.isChecked) {
                context._countDownEach();
            } else {
                context._countUpEach();
            }
        }
    }, {
        key: '_countUpEach',
        value: function _countUpEach() {
            var context = this,
                options = context.params,
                $target = $(options.targetSelector);

            options.isChecked = true;

            $target.each(function() {
                var $this = $(this),
                    currentDataSettings = $this.attr('data-hs-toggle-switch-item-options') ? JSON.parse($this.attr('data-hs-toggle-switch-item-options')) : {};

                var currentDefaults = {
                        duration: .5,
                        useEasing: false
                    },
                    currentOptions = {};
                currentOptions = $.extend(true, currentDefaults, currentDataSettings);

                context._countUp($this, currentOptions);
            });
        }
    }, {
        key: '_countDownEach',
        value: function _countDownEach() {
            var context = this,
                options = context.params,
                $target = $(options.targetSelector);

            options.isChecked = false;

            $target.each(function() {
                var $this = $(this),
                    currentDataSettings = $this.attr('data-hs-toggle-switch-item-options') ? JSON.parse($this.attr('data-hs-toggle-switch-item-options')) : {};

                var currentDefaults = {
                        duration: .5,
                        useEasing: false
                    },
                    currentOptions = {};
                currentOptions = $.extend(true, currentDefaults, currentDataSettings);

                context._countDown($this, currentOptions);
            });
        }
    }, {
        key: '_countUp',
        value: function _countUp(el, data) {
            var defaults = {
                startVal: data.min
            };
            var options = $.extend(true, defaults, data);

            var countUp = new _countup.CountUp(el[0], data.max, options);

            countUp.start();
        }
    }, {
        key: '_countDown',
        value: function _countDown(el, data) {
            var defaults = {
                startVal: data.max
            };
            var options = $.extend(true, defaults, data);

            var countUp = new _countup.CountUp(el[0], data.min, options);

            countUp.start();
        }
    }]);

    return HSToggleSwitch;
}();

exports.default = HSToggleSwitch;