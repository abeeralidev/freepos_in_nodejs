Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

/*
 * HSToggleState Plugin
 * @version: 2.0.0 (Mon, 25 Nov 2019)
 * @requires: jQuery v3.0 or later
 * @author: HtmlStream
 * @event-namespace: .HSToggleState
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */

var HSToggleState = function() {
    function HSToggleState(elem, settings) {
        _classCallCheck(this, HSToggleState);

        this.elem = elem;
        this.defaults = {
            targetSelector: null,
            slaveSelector: null,

            classMap: {
                toggle: 'toggled'
            }
        };
        this.settings = settings;
    }

    _createClass(HSToggleState, [{
        key: 'init',
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-toggle-state-options') ? JSON.parse($el.attr('data-hs-toggle-state-options')) : {},
                options = $.extend(true, context.defaults, dataSettings, context.settings);

            context._prepareObject($el, options);

            $el.on('click', function() {
                $el.toggleClass(options.classMap.toggle);

                if (options.slaveSelector) {
                    if ($el.hasClass(options.classMap.toggle)) {
                        $(options.slaveSelector).addClass(options.classMap.toggle);
                    } else {
                        $(options.slaveSelector).removeClass(options.classMap.toggle);
                    }
                }

                context._checkState($el, options);
            });

            $(options.slaveSelector).on('click', function() {
                $('[data-hs-toggle-state-slave="' + options.slaveSelector + '"]').removeClass(options.classMap.toggle);
            });
        }
    }, {
        key: '_prepareObject',
        value: function _prepareObject(el, params) {
            var options = params;

            el.attr('data-hs-toggle-state-slave', options.slaveSelector);
        }
    }, {
        key: '_checkState',
        value: function _checkState(el, params) {
            var options = params;

            if (el.hasClass(options.classMap.toggle)) {
                $(options.targetSelector).prop('checked', true);
            } else {
                $(options.targetSelector).prop('checked', false);
            }
        }
    }]);

    return HSToggleState;
}();

exports.default = HSToggleState;