__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSAddField;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

/*
 * HSCounter Plugin
 * @version: 2.0.0 (Mon, 25 Nov 2019)
 * @requires: jQuery v3.0 or later
 * @author: HtmlStream
 * @event-namespace: .HSAddField
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */
var HSAddField = /*#__PURE__*/ function() {
    function HSAddField(element, config) {
        _classCallCheck(this, HSAddField);

        this.element = element;
        this.defaults = {
            createTrigger: '.js-create-field',
            deleteTrigger: '.js-delete-field',
            limit: 5,
            defaultCreated: 1,
            nameSeparator: '_',
            addedField: function addedField() {},
            deletedField: function deletedField() {}
        };
        this.config = config;
        this.flags = {
            name: 'data-name',
            "delete": 'data-hs-add-field-delete'
        };
        this.fieldsCount = 0;
    }

    _createClass(HSAddField, [{
        key: "init",
        value: function init() {
            var _this = this;

            var self = this,
                element = this.element,
                dataSettings = $(element).attr('data-hs-add-field-options') ? JSON.parse($(element).attr('data-hs-add-field-options')) : {};
            this.config = Object.assign({}, this.defaults, this.config, dataSettings);
            this.fieldsCount = this.config.defaultCreated;

            for (var i = 0; i < this.config.defaultCreated; i++) {
                this.__addField(this.config);
            }

            $(this.element).on('click', this.config.createTrigger, function() {
                _this.__addField(_this.config);
            });
            $(this.element).on('click', this.config.deleteTrigger, function(e) {
                _this.__deleteField(_this.config, $(e.currentTarget).attr(_this.flags["delete"]));
            });
        }
    }, {
        key: "__addField",
        value: function __addField(params) {
            var settings = params;

            if (this.fieldsCount < settings.limit) {
                var field = $(settings.template).clone().removeAttr('id').css({
                    display: ''
                }).appendTo($(settings.container));

                this.__updateFieldsCount();

                this.__renderName();

                this.__renderKeys();

                this.__toggleCreateButton();

                this.config.addedField();
            }
        }
    }, {
        key: "__deleteField",
        value: function __deleteField(params, index) {
            var settings = params;

            if (this.fieldsCount > 0) {
                $(settings.container).children()[index].remove();

                this.__updateFieldsCount();

                this.__renderName();

                this.__renderKeys();

                this.__toggleCreateButton();

                this.config.deletedField();
            }
        }
    }, {
        key: "__renderName",
        value: function __renderName() {
            var _this2 = this;

            $(this.config.container).children().each(function(i, el) {
                var key = i;
                $(el).find("[".concat(_this2.flags.name, "]")).each(function(i, el) {
                    var name = $(el).attr(_this2.flags.name);
                    $(el).attr('name', name + _this2.config.nameSeparator + key);
                });
            });
        }
    }, {
        key: "__renderKeys",
        value: function __renderKeys() {
            var _this3 = this;

            $(this.config.container).children().find(this.config.deleteTrigger).each(function(i, el) {
                $(el).attr(_this3.flags["delete"], i);
            });
        }
    }, {
        key: "__updateFieldsCount",
        value: function __updateFieldsCount() {
            this.fieldsCount = $(this.config.container).children().length;
        }
    }, {
        key: "__toggleCreateButton",
        value: function __toggleCreateButton() {
            if (this.fieldsCount === this.config.limit) {
                $(this.config.createTrigger).fadeOut(0);
            } else {
                $(this.config.createTrigger).fadeIn(0);
            }
        }
    }]);

    return HSAddField;
}();