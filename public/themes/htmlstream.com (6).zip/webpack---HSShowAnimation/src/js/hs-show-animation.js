Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

/*
 * HSShowAnimation Plugin
 * @version: 2.0.0 (Mon, 25 Nov 2019)
 * @requires: jQuery v3.0 or later
 * @author: HtmlStream
 * @event-namespace: .HSShowAnimation
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */

var HSShowAnimation = function() {
    function HSShowAnimation(elem, settings) {
        _classCallCheck(this, HSShowAnimation);

        this.elem = elem;
        this.defaults = {
            groupName: null,
            targetSelector: null,
            siblingSelector: null,
            eventType: 'click',

            classMap: {
                active: 'active'
            },

            animationType: 'simple',
            animationInit: 'animated',
            animationIn: null,
            duration: null,

            afterShow: function afterShow() {}
        };
        this.settings = settings;
    }

    _createClass(HSShowAnimation, [{
        key: 'init',
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-show-animation-options') ? JSON.parse($el.attr('data-hs-show-animation-options')) : {},
                options = $.extend(true, context.defaults, dataSettings, context.settings);

            context._prepareObject($el, options);

            $el.on(options.eventType, function(e) {
                e.preventDefault();

                if ($el.hasClass(options.classMap.active)) {
                    return;
                }

                context._activeClassChange($el, options);

                if (options.animationType === 'css-animation') {
                    context._cssAnimation($el, options);
                } else {
                    context._simpleAnimation($el, options);
                }
            });
        }
    }, {
        key: '_prepareObject',
        value: function _prepareObject(el, params) {
            var options = params;

            el.attr('data-hs-show-animation-link-group', options.groupName);

            if (options.duration) {
                $(options.targetSelector).css({
                    animationDuration: options.duration + 'ms'
                });
            }

            $(options.targetSelector).attr('data-hs-show-animation-target-group', options.groupName);

            if (options.siblingSelector) {
                $(options.siblingSelector).attr('data-hs-show-animation-target-group', options.groupName);
            }
        }
    }, {
        key: '_activeClassChange',
        value: function _activeClassChange(el, params) {
            var options = params;

            $('[data-hs-show-animation-link-group="' + options.groupName + '"]').removeClass(options.classMap.active);

            el.addClass(options.classMap.active);
        }
    }, {
        key: '_simpleAnimation',
        value: function _simpleAnimation(el, params) {
            var options = params;

            $('[data-hs-show-animation-target-group="' + options.groupName + '"]').hide().css({
                opacity: 0
            });

            $(options.targetSelector).show().css({
                opacity: 1
            });

            options.afterShow();
        }
    }, {
        key: '_cssAnimation',
        value: function _cssAnimation(el, params) {
            var options = params;

            $('[data-hs-show-animation-target-group="' + options.groupName + '"]').hide().css({
                opacity: 0
            }).removeClass(options.animationInit + ' ' + options.animationIn);

            $(options.targetSelector).show();

            options.afterShow();

            setTimeout(function() {
                $(options.targetSelector).css({
                    opacity: 1
                }).addClass(options.animationInit + ' ' + options.animationIn);
            }, 50);
        }
    }]);

    return HSShowAnimation;
}();

exports.default = HSShowAnimation;