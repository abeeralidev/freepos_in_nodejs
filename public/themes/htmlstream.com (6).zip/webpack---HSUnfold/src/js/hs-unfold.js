__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSUnfold;
});
/* harmony import */
var _methods_smart_position__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__( /*! ./methods/smart-position */ "./src/js/methods/smart-position.js");
/* harmony import */
var _methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__( /*! ./methods/close-element-with-specific-effect */ "./src/js/methods/close-element-with-specific-effect.js");
/* harmony import */
var _modes_simple__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__( /*! ./modes/simple */ "./src/js/modes/simple.js");
/* harmony import */
var _methods_simple_show__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__( /*! ./methods/simple-show */ "./src/js/methods/simple-show.js");
/* harmony import */
var _modes_css_animation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__( /*! ./modes/css-animation */ "./src/js/modes/css-animation.js");
/* harmony import */
var _methods_css_animation_show__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__( /*! ./methods/css-animation-show */ "./src/js/methods/css-animation-show.js");
/* harmony import */
var _modes_slide__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__( /*! ./modes/slide */ "./src/js/modes/slide.js");
/* harmony import */
var _methods_slide_show__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__( /*! ./methods/slide-show */ "./src/js/methods/slide-show.js");

function _typeof(obj) {
    "@babel/helpers - typeof";
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}










var HSUnfold = /*#__PURE__*/ function() {
    function HSUnfold(elem, settings) {
        _classCallCheck(this, HSUnfold);

        this.elem = elem;
        this.defaults = {
            event: 'click',
            type: 'simple',
            duration: 300,
            delay: 350,
            easing: 'linear',
            animationIn: 'slideInUp',
            animationOut: 'fadeOut',
            hideOnScroll: false,
            hasOverlay: false,
            smartPositionOff: false,
            smartPositionOffEl: false,
            isFullWindow: false,
            wrapperSelector: '.hs-unfold',
            contentSelector: '.hs-unfold-content',
            invokerSelector: '.js-hs-unfold-invoker',
            invokerActiveClass: '.hs-active',
            overlayClass: '.hs-unfold-overlay',
            overlayStyles: {},
            initializedClass: '.hs-unfold-content-initialized',
            hiddenClass: '.hs-unfold-hidden',
            simpleEffectClass: '.hs-unfold-simple',
            cssAnimationClass: '.hs-unfold-css-animation',
            cssAnimatedClass: '.animated',
            slideEffectClass: '.hs-unfold-jquery-slide',
            reverseClass: '.hs-unfold-reverse-y',
            unfoldTimeOut: null,
            afterOpen: function afterOpen() {},
            afterClose: function afterClose() {}
        };
        this.settings = settings;
    }

    _createClass(HSUnfold, [{
        key: "init",
        value: function init() {
            var context = this; // Keycodes

            var ESC_KEYCODE = 27,
                TAB_KEYCODE = 9,
                ENTER_KEYCODE = 13,
                SPACE_KEYCODE = 32,
                ARROW_UP_KEYCODE = 38,
                ARROW_DOWN_KEYCODE = 40,
                ARROW_RIGHT_KEYCODE = 39,
                ARROW_LEFT_KEYCODE = 37; // Prevent scroll

            function preventScroll(keycode) {
                return function(e) {
                    if (e.which === keycode) {
                        e.preventDefault();
                    }
                };
            } // Get Item Settings


            function getItemSettings(el) {
                var $el = el,
                    dataSettings = $el.attr('data-hs-unfold-options') ? JSON.parse($el.attr('data-hs-unfold-options')) : {};
                var options = Object.assign({}, context.defaults, context.settings, dataSettings);
                return options;
            } // Init Unfold


            $(this.elem).each(function() {
                context.UnfoldItem($(this));
            }); // *****
            // Start: ACCESSIBILITY
            // *****

            var myPreventScrollSpace = preventScroll(SPACE_KEYCODE),
                myPreventScrollDown = preventScroll(ARROW_DOWN_KEYCODE),
                myPreventScrollUp = preventScroll(ARROW_UP_KEYCODE);
            var $items, index, itemSettings;
            $(document).on('keyup', '[data-hs-unfold-invoker], [data-hs-unfold-content]', function(e) {
                if (e.which !== ESC_KEYCODE && e.which !== TAB_KEYCODE && e.which !== ENTER_KEYCODE && e.which !== ARROW_UP_KEYCODE && e.which !== ARROW_DOWN_KEYCODE || _typeof($(e.target).attr('data-hs-unfold-invoker')) == (true ? "undefined" : undefined)) {
                    return;
                } //
                // Start: PREVENT SCROLL
                //


                e.preventDefault();
                e.stopPropagation();
                window.addEventListener('keydown', myPreventScrollSpace, false);
                window.addEventListener('keydown', myPreventScrollUp, false);
                window.addEventListener('keydown', myPreventScrollDown, false); //
                // End: PREVENT SCROLL
                //

                if (_typeof($(e.target).attr('data-hs-unfold-invoker')) !== (true ? "undefined" : undefined) && $(e.target).attr('data-hs-unfold-invoker') !== false) {
                    itemSettings = getItemSettings($(e.target));
                    $items = [].slice.call($(itemSettings.target).find('a, button, input, select, textarea')).filter(function(item) {
                        return $(item).is(':visible');
                    });
                }

                index = $items.indexOf(e.target); //
                // End: HAS ITEMS
                //
                // Up

                if ($items.length > 0 && e.which === ARROW_UP_KEYCODE && index > 0) {
                    index--;
                } // Down


                if ($items.length > 0 && e.which === ARROW_DOWN_KEYCODE && index < $items.length - 1) {
                    index++;
                } // Open Dropdown


                if ($items.length <= 0 && (e.which === ARROW_DOWN_KEYCODE || e.which === ARROW_UP_KEYCODE || e.which === SPACE_KEYCODE || e.which === ENTER_KEYCODE)) {
                    if (!$("".concat(itemSettings.target, ":visible")).length) {
                        $(e.target).addClass(itemSettings.invokerActiveClass.slice(1));

                        if (itemSettings.type === 'css-animation') {
                            Object(_methods_css_animation_show__WEBPACK_IMPORTED_MODULE_5__["default"])($(itemSettings.target), itemSettings);
                        } else if (itemSettings.type === 'jquery-slide') {
                            Object(_methods_slide_show__WEBPACK_IMPORTED_MODULE_7__["default"])($(itemSettings.target), itemSettings, function() {});
                        } else {
                            Object(_methods_simple_show__WEBPACK_IMPORTED_MODULE_3__["default"])($(itemSettings.target), itemSettings);
                        }
                    } else if ($("".concat(itemSettings.target, ":visible")).length) {
                        $($(itemSettings.target).find('a')[0]).focus();
                        return;
                    }
                } // Close Self


                if (e.which === ESC_KEYCODE) {
                    var _$target = $("".concat(itemSettings.contentSelector, ":not(").concat(itemSettings.hiddenClass, ")")); // $(itemSettings.invokerActiveClass).focus();


                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])(_$target, itemSettings, _$target.data('hs-unfold-content-animation-in'), _$target.data('hs-unfold-content-animation-out'));
                    return;
                } // Close All


                if (e.which === TAB_KEYCODE && $(e.target).closest('[data-hs-unfold-content]').length === 0) {
                    var $invoker = $('[data-hs-unfold-invoker].hs-active'),
                        $target = $('[data-hs-unfold-content]:visible'),
                        openedItemSettings = getItemSettings($invoker);
                    $invoker.removeClass('hs-active');
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($target, openedItemSettings, $target.data('hs-unfold-content-animation-in'), $target.data('hs-unfold-content-animation-out'));
                    return;
                } //
                // End: HAS ITEMS
                //


                $($items[index]).focus();
            });
            $(document).on('keyup', function(e) {
                var $invoker, $target, openedItemSettings; // Close All

                if (e.which === TAB_KEYCODE && $(e.target).closest('[data-hs-unfold-content]').length === 0) {
                    $invoker = $('[data-hs-unfold-invoker].hs-active');
                    $target = $('[data-hs-unfold-content]:visible');
                    openedItemSettings = getItemSettings($invoker);
                    $invoker.removeClass('hs-active');
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($target, openedItemSettings, $target.data('hs-unfold-content-animation-in'), $target.data('hs-unfold-content-animation-out'));
                } // Close Self


                if (e.which === ESC_KEYCODE) {
                    $invoker = $('[data-hs-unfold-invoker].hs-active');
                    $target = $('[data-hs-unfold-content]:visible');
                    openedItemSettings = getItemSettings($invoker);
                    $invoker.removeClass('hs-active');
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($target, openedItemSettings, $target.data('hs-unfold-content-animation-in'), $target.data('hs-unfold-content-animation-out'));
                }
            }); // *****
            // End: ACCESSIBILITY
            // *****
        }
    }, {
        key: "UnfoldItem",
        value: function UnfoldItem(el) {
            var context = this,
                $el = el,
                itemDataSettings = el.attr('data-hs-unfold-options') ? JSON.parse(el.attr('data-hs-unfold-options')) : {};
            var options = Object.assign({}, context.defaults, context.settings, itemDataSettings),
                originalEvent = options.event;

            context._prepareObjects($el, $(options.target), options);

            function closeFunc() {
                $(options.contentSelector).not($(options.target)).not($(options.target).parents(options.contentSelector)).each(function() {
                    $(options.invokerSelector).removeClass(options.invokerActiveClass.slice(1));
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($(this), options, $(this).attr('data-hs-unfold-content-animation-in'), $(this).attr('data-hs-unfold-content-animation-out'));
                });
            }

            if (window.navigator.userAgent.indexOf('Mobile') !== -1) {
                options.event = 'click';
            } else {
                options.event = originalEvent;
            }

            $el.on(options.event === 'hover' ? 'mouseenter' : 'click', closeFunc);
            $(window).on('resize', function() {
                if (window.navigator.userAgent.indexOf('Mobile') !== -1) {
                    options.event = 'click';
                } else {
                    options.event = originalEvent;
                }

                $el[0].addEventListener(options.event === 'hover' ? 'mouseenter' : 'click', closeFunc);
            });

            if (options.type === 'css-animation') {
                Object(_modes_css_animation__WEBPACK_IMPORTED_MODULE_4__["default"])($el, options, options.animationOut);
            } else if (options.type === 'jquery-slide') {
                Object(_modes_slide__WEBPACK_IMPORTED_MODULE_6__["default"])($el, options);
            } else {
                Object(_modes_simple__WEBPACK_IMPORTED_MODULE_2__["default"])($el, options);
            } // Document Events


            $(window).on('click', function(e) {
                var targetClass = "".concat(options.contentSelector, ":not(").concat(options.hiddenClass, ")"),
                    $target = $(targetClass);

                if ($(e.target).closest(options.contentSelector).length === 0 && $(e.target).closest(options.invokerSelector).length === 0 && $target.length !== 0) {
                    $el.removeClass(options.invokerActiveClass.slice(1));
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($target, options, $target.data('hs-unfold-content-animation-in'), $target.data('hs-unfold-content-animation-out'));
                } else if ($(e.target).closest(options.contentSelector).length !== 0 && $(e.target).closest(options.contentSelector).find(options.contentSelector).length !== 0 && $(e.target).closest(options.invokerSelector).length === 0 && !options.hasOverlay) {
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($(e.target).closest(options.contentSelector).find(targetClass), options, $(e.target).closest(options.contentSelector).find(targetClass).data('hs-unfold-content-animation-in'), $(e.target).closest(options.contentSelector).find(targetClass).data('hs-unfold-content-animation-out'));
                }
            }); // Resize and Scroll Events

            $(window).on('resize scroll', function() {
                if (!options.smartPositionOff) {
                    Object(_methods_smart_position__WEBPACK_IMPORTED_MODULE_0__["default"])($(options.target), $el, options);
                }
            });

            if (options.hideOnScroll) {
                $(window).on('scroll', function() {
                    $el.removeClass(options.invokerActiveClass.slice(1));
                    Object(_methods_close_element_with_specific_effect__WEBPACK_IMPORTED_MODULE_1__["default"])($(options.target), options, options.animationIn, options.animationOut);
                });
            }
        }
    }, {
        key: "_prepareObjects",
        value: function _prepareObjects(el, target, config) {
            el.addClass(config.invokerSelector.slice(1));
            el.attr('data-hs-unfold-target', config.target);
            el.attr('data-hs-unfold-invoker', '');
            target.attr('data-hs-target-height', target.outerHeight());
            target.attr('data-hs-unfold-content', '');
            target.addClass("".concat(config.hiddenClass.slice(1), " ").concat(config.initializedClass.slice(1)));

            if (config.hasOverlay && $(config.overlayClass).length === 0) {
                $('body').append($("<div class=\"".concat(config.overlayClass.slice(1), "\"></div>")).css(config.overlayStyles));
            }

            if (config.type === 'css-animation') {
                target.attr('data-hs-unfold-content-animation-in', config.animationIn);
                target.attr('data-hs-unfold-content-animation-out', config.animationOut);
            }
        }
    }]);

    return HSUnfold;
}();