__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return slide;
});
/* harmony import */
var _methods_smart_position__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__( /*! ../methods/smart-position */ "./src/js/methods/smart-position.js");
/* harmony import */
var _methods_slide_show__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__( /*! ../methods/slide-show */ "./src/js/methods/slide-show.js");
/* harmony import */
var _methods_slide_hide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__( /*! ../methods/slide-hide */ "./src/js/methods/slide-hide.js");
/* harmony import */
var _methods_simple_hide__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__( /*! ../methods/simple-hide */ "./src/js/methods/simple-hide.js");
/* harmony import */
var _methods_simple_show__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__( /*! ../methods/simple-show */ "./src/js/methods/simple-show.js");





function slide(el, config) {
    $(config.target).addClass(config.slideEffectClass.slice(1)).css('display', 'none');

    function clickFunc() {
        if (!$(config.target).hasClass(config.hiddenClass.slice(1))) {
            Object(_methods_slide_hide__WEBPACK_IMPORTED_MODULE_2__["default"])($(config.target), config, function() {
                el.removeClass(config.invokerActiveClass.slice(1));
            });
        } else {
            Object(_methods_slide_show__WEBPACK_IMPORTED_MODULE_1__["default"])($(config.target), config, function() {
                el.addClass(config.invokerActiveClass.slice(1));
            });

            if (!config.smartPositionOff) {
                Object(_methods_smart_position__WEBPACK_IMPORTED_MODULE_0__["default"])($(config.target), el, config);
            }
        }
    }

    function mouseEnterFunc() {
        Object(_methods_slide_show__WEBPACK_IMPORTED_MODULE_1__["default"])($(config.target), config, function() {
            el.addClass(config.invokerActiveClass.slice(1));
        });

        if (!config.smartPositionOff) {
            Object(_methods_smart_position__WEBPACK_IMPORTED_MODULE_0__["default"])($(config.target), el, config);
        }
    }

    function mouseLeaveFunc() {
        Object(_methods_slide_hide__WEBPACK_IMPORTED_MODULE_2__["default"])($(config.target), config, function() {
            el.removeClass(config.invokerActiveClass.slice(1));
        });
    }

    function initSlide() {
        if (window.navigator.userAgent.indexOf('Mobile') !== -1) {
            el[0].addEventListener('click', clickFunc);
        } else {
            if (config.event === 'hover') {
                // Hover
                el.parent(config.wrapperSelector)[0].addEventListener('mouseenter', mouseEnterFunc);
                el.parent(config.wrapperSelector)[0].addEventListener('mouseleave', mouseLeaveFunc);
            } else {
                // Click
                el[0].addEventListener('click', clickFunc);
            }
        }
    }

    $(window).on('resize', function() {
        initSlide();
    });
    initSlide();
}