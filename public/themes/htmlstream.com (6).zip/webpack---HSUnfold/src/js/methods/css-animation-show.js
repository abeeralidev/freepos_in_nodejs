__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return cssAnimationShow;
});

function cssAnimationShow(target, config) {
    if (config.cssAnimatedClass) {
        target.removeClass("".concat(config.hiddenClass.slice(1), " ").concat(config.animationOut)).addClass(config.animationIn);
    } else {
        target.removeClass("".concat(config.hiddenClass.slice(1), " ").concat(config.animationOut));
        setTimeout(function() {
            target.addClass(config.animationIn);
        });
    }
}