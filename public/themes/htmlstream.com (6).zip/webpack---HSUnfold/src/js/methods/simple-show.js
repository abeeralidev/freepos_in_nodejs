__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return simpleShow;
});

function simpleShow(target, config) {
    target.removeClass(config.hiddenClass.slice(1));

    if (config.hasOverlay) {
        $(config.overlayClass).show();
    }

    config.afterOpen();
}