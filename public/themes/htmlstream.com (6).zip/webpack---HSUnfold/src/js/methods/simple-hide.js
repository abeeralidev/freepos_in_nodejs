__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return simpleHide;
});

function simpleHide(target, config) {
    target.addClass(config.hiddenClass.slice(1));

    if (config.hasOverlay) {
        $(config.overlayClass).hide();
    }

    config.afterClose();
}