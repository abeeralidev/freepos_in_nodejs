__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return slideHide;
});

function slideHide(target, config, callback) {
    target.slideUp({
        duration: config.duration,
        easing: config.easing,
        complete: function complete() {
            callback();
            config.afterClose();
            target.addClass(config.hiddenClass.slice(1));
        }
    });

    if (config.hasOverlay) {
        $(config.overlayClass).fadeOut(200);
    }
}