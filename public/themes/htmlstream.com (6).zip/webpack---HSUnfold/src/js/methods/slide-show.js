__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return slideShow;
});

function slideShow(target, config, callback) {
    target.removeClass(config.hiddenClass.slice(1)).stop().slideDown({
        duration: config.duration,
        easing: config.easing,
        complete: function complete() {
            callback();
            config.afterOpen();
        }
    });

    if (config.hasOverlay) {
        $(config.overlayClass).fadeIn(200);
    }
}