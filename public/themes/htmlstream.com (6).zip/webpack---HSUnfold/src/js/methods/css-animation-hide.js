__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return cssAnimationHide;
});

function cssAnimationHide(target, config, effect) {
    target.removeClass($(target).attr('data-hs-unfold-content-animation-in')).addClass(effect);
}