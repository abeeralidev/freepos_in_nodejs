__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return closeElementWithSpecificEffect;
});
/* harmony import */
var _methods_simple_hide__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__( /*! ../methods/simple-hide */ "./src/js/methods/simple-hide.js");
/* harmony import */
var _css_animation_hide__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__( /*! ./css-animation-hide */ "./src/js/methods/css-animation-hide.js");
/* harmony import */
var _methods_slide_hide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__( /*! ../methods/slide-hide */ "./src/js/methods/slide-hide.js");



function closeElementWithSpecificEffect(el, config, cssAnimationShowEffect, cssAnimationHideEffect) {
    if (el.hasClass(config.hiddenClass.slice(1))) return;

    if (el.hasClass(config.cssAnimationClass.slice(1))) {
        Object(_css_animation_hide__WEBPACK_IMPORTED_MODULE_1__["default"])(el, config, cssAnimationHideEffect);
        el.on('animationend webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend', function(e) {
            if (el.hasClass(cssAnimationHideEffect)) {
                el.removeClass(cssAnimationHideEffect).addClass(config.hiddenClass.slice(1));
                config.afterClose();
            }

            if (el.hasClass(cssAnimationShowEffect)) {
                config.afterOpen();
            }

            e.preventDefault();
            e.stopPropagation();
        });
    } else if (el.hasClass(config.slideEffectClass.slice(1))) {
        Object(_methods_slide_hide__WEBPACK_IMPORTED_MODULE_2__["default"])(el, config, function() {});
    } else {
        Object(_methods_simple_hide__WEBPACK_IMPORTED_MODULE_0__["default"])(el, config);
    }
}