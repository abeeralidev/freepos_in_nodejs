Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var HSScrollToInOverflowedContainer = function() {
    function HSScrollToInOverflowedContainer(elem, settings) {
        _classCallCheck(this, HSScrollToInOverflowedContainer);

        this.elem = elem;
        this.defaults = {
            speed: 500,
            targetEl: null
        };
        this.settings = settings;
    }

    _createClass(HSScrollToInOverflowedContainer, [{
        key: 'init',
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-scroll-to-in-overflowed-container-options') ? JSON.parse($el.attr('data-hs-scroll-to-in-overflowed-container-options')) : {},
                options = $.extend(true, context.defaults, dataSettings, context.settings);

            context._scrollToTarget($el, options);
        }
    }, {
        key: '_scrollToTarget',
        value: function _scrollToTarget(el, params) {
            var options = params;

            el.animate({
                scrollTop: el.scrollTop() - el.offset().top + $(options.targetEl).offset().top
            }, options.speed);

            return this;
        }
    }]);

    return HSScrollToInOverflowedContainer;
}();

exports.default = HSScrollToInOverflowedContainer;