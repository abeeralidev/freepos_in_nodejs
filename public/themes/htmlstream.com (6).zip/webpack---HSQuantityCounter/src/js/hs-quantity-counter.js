Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var HSQuantityCounter = function() {
    function HSQuantityCounter(elem, settings) {
        _classCallCheck(this, HSQuantityCounter);

        this.elem = elem;
        this.defaults = {
            classMap: {
                plus: '.js-plus',
                minus: '.js-minus',
                result: '.js-result'
            },

            resultVal: null
        };
        this.settings = settings;
    }

    _createClass(HSQuantityCounter, [{
        key: 'init',
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-quantity-counter-options') ? JSON.parse($el.attr('data-hs-quantity-counter-options')) : {},
                options = $.extend(true, context.defaults, dataSettings, context.settings);

            // Change Default Values
            options.resultVal = parseInt($el.find(options.classMap.result).val());

            // Plus Click Events
            $el.find(options.classMap.plus).on('click', function() {
                context._plusClickEvents($el, options);
            });

            // Minus Click Events
            $el.find(options.classMap.minus).on('click', function() {
                context._minusClickEvents($el, options);
            });
        }
    }, {
        key: '_plusClickEvents',
        value: function _plusClickEvents(el, params) {
            var options = params;

            options.resultVal += 1;

            el.find(options.classMap.result).val(options.resultVal);
        }
    }, {
        key: '_minusClickEvents',
        value: function _minusClickEvents(el, params) {
            var options = params;

            if (options.resultVal >= 1) {
                options.resultVal -= 1;

                el.find(options.classMap.result).val(options.resultVal);
            } else {
                return false;
            }
        }
    }]);

    return HSQuantityCounter;
}();

exports.default = HSQuantityCounter;