__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSVideoBg;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

/*
 * HSVideoBg Plugin
 * @version: 2.0.0 (Mon, 25 Nov 2019)
 * @requires: jQuery v3.0 or later
 * @author: HtmlStream
 * @event-namespace: .HSVideoBg
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */
var HSVideoBg = /*#__PURE__*/ function() {
    function HSVideoBg(elem, settings) {
        _classCallCheck(this, HSVideoBg);

        this.elem = elem;
        this.defaults = {
            type: 'default',
            videoId: null,
            isLoop: true,
            ratio: 1.5
        };
        this.settings = settings;
    }

    _createClass(HSVideoBg, [{
        key: "init",
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-video-bg-options') ? JSON.parse($el.attr('data-hs-video-bg-options')) : {};
            var options = $.extend(true, context.defaults, dataSettings, context.settings);

            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                return;
            }

            context._prepareObject($el, options);

            if (options.type === 'you-tube') {
                context._APICreating('//www.youtube.com/player_api', 'YT', 'YTDetect').then(function() {
                    var newYT;

                    if (typeof window.onYouTubeIframeAPIReady === 'function') {
                        setTimeout(function() {
                            newYT = new YT.Player($el.find('.hs-video-bg-video > div')[0], {
                                videoId: options.videoId,
                                playerVars: {
                                    autoplay: true,
                                    controls: 0,
                                    showinfo: 0,
                                    enablejsapi: 1,
                                    modestbranding: 1,
                                    iv_load_policy: 3,
                                    loop: options.isLoop,
                                    playlist: options.videoId,
                                    origin: window.location.origin
                                },
                                events: {
                                    onReady: function onReady(e) {
                                        e.target.mute();
                                        $(window).on('resize', function() {
                                            context._ratioCalc($el, options);
                                        }).trigger('resize');
                                        $el.find('.hs-video-bg-preview').fadeOut(400);
                                    }
                                }
                            });
                        }, 100);
                    } else {
                        window.onYouTubeIframeAPIReady = function() {
                            newYT = new YT.Player($el.find('.hs-video-bg-video > div')[0], {
                                videoId: options.videoId,
                                playerVars: {
                                    autoplay: true,
                                    controls: 0,
                                    showinfo: 0,
                                    enablejsapi: 1,
                                    modestbranding: 1,
                                    iv_load_policy: 3,
                                    loop: options.isLoop,
                                    playlist: options.videoId,
                                    origin: window.location.origin
                                },
                                events: {
                                    onReady: function onReady(e) {
                                        e.target.mute();
                                        $(window).on('resize', function() {
                                            context._ratioCalc($el, options);
                                        }).trigger('resize');
                                        $el.find('.hs-video-bg-preview').fadeOut(400);
                                    }
                                }
                            });
                        };
                    }
                });
            } else if (options.type === 'vimeo') {
                context._APICreating('//player.vimeo.com/api/player.js', 'Vimeo', 'VimeoDetect').then(function() {
                    var newVimeo = new Vimeo.Player($el.find('.hs-video-bg-video')[0], {
                        id: options.videoId,
                        loop: options.isLoop,
                        title: false,
                        portrait: false,
                        byline: false,
                        autoplay: true,
                        autopause: false,
                        muted: true
                    });
                    newVimeo.play().then(function() {
                        $(window).on('resize', function() {
                            context._ratioCalc($el, options);
                        }).trigger('resize');
                        $el.find('.hs-video-bg-preview').fadeOut(400);
                    });
                });
            } else {
                $(window).on('resize', function() {
                    context._ratioCalc($el, options);
                });
                setTimeout(function() {
                    $(window).trigger('resize');
                });
            }
        }
    }, {
        key: "_prepareObject",
        value: function _prepareObject(el, params) {
            var context = this;
            var options = params;
            el.css({
                position: 'relative'
            });

            if (options.type === 'you-tube') {
                el.append('<div class="hs-video-bg-video"><div></div></div>');
            } else if (options.type === 'vimeo') {
                el.append('<div class="hs-video-bg-video"></div>');
            } else {
                el.append("\n\t\t\t\t<div class=\"hs-video-bg-video\">\n\t\t\t\t\t<video poster=\"\" autoplay muted ".concat(options.isLoop ? 'loop' : '', ">\n\t\t\t\t\t\t<source src=\"").concat(options.videoId, ".mp4\" type=\"video/mp4\">\n\t\t\t\t\t\t<source src=\"").concat(options.videoId, ".webm\" type=\"video/webm\">\n\t\t\t\t\t\t<source src=\"").concat(options.videoId, ".ogv\" type=\"video/ogg\">\n\t\t\t\t\t\tYour browser doesn't support HTML5 video.\n\t\t\t\t\t</video>\n        </div>\n\t\t\t"));
            }

            if (options.type === 'you-tube') {
                el.append("<div class=\"hs-video-bg-preview\" style=\"background-image: url(//img.youtube.com/vi/".concat(options.videoId, "/maxresdefault.jpg);\"></div>"));
            } else if (options.type === 'vimeo') {
                $.getJSON("//www.vimeo.com/api/v2/video/".concat(options.videoId, ".json?callback=?"), function(data) {
                    el.append("<div class=\"hs-video-bg-preview\" style=\"background-image: url(".concat(data[0].thumbnail_large, ");\"></div>"));
                });
            } else {
                return false;
            }
        }
    }, {
        key: "_ratioCalc",
        value: function _ratioCalc(el, params) {
            var options = params,
                _ratio = el.outerWidth() / el.outerHeight();

            if (options.type === 'you-tube' || options.type === 'vimeo') {
                if (el.outerHeight() < el.outerWidth() && window.innerWidth > 768) {
                    el.find('.hs-video-bg-video').css({
                        width: _ratio * el.outerWidth() * options.ratio,
                        height: _ratio * el.outerHeight() * options.ratio // height: window.innerWidth > 1600 ? (options.ratio * el.outerHeight() * 0.4) : (options.ratio * el.outerHeight())

                    });
                } else {
                    el.find('.hs-video-bg-video').css({
                        width: _ratio * el.outerWidth(),
                        height: '130%'
                    });
                }
            }
        }
    }, {
        key: "_APICreating",
        value: function _APICreating(scriptUrl, globalName, globalNameDetect) {
            if (window[globalNameDetect]) {
                return Promise.resolve();
            }

            return new Promise(function(resolve, reject) {
                var script = document.createElement('script'),
                    before = document.getElementsByTagName('script')[0];
                script.src = scriptUrl;
                before.parentNode.insertBefore(script, before);

                script.onload = function() {
                    !globalName || window[globalName] ? resolve() : reject(Error('window.' + globalName + ' undefined'));
                };

                script.onerror = function() {
                    reject(Error('Error loading ' + globalName || false));
                };
            });
        }
    }]);

    return HSVideoBg;
}();