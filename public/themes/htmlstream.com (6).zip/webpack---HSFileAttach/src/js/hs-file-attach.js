__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */
__webpack_require__.d(__webpack_exports__, "default", function() {
    return HSFileAttach;
});

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}

function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}

/*
 * HSFileAttach Plugin
 * @version: 2.0.0 (Mon, 25 Nov 2019)
 * @requires: jQuery v3.0 or later
 * @author: HtmlStream
 * @event-namespace: .HSFileAttach
 * @license: Htmlstream Libraries (https://htmlstream.com/)
 * Copyright 2019 Htmlstream
 */
var HSFileAttach = /*#__PURE__*/ function() {
    function HSFileAttach(elem, settings) {
        _classCallCheck(this, HSFileAttach);

        this.elem = elem;
        this.defaults = {
            textTarget: null,
            maxFileSize: 1024,
            // Infinity - off file size detection
            errorMessage: 'File is too big!',
            mode: 'simple',
            targetAttr: null,
            resetTarget: null
        };
        this.settings = settings;
    }

    _createClass(HSFileAttach, [{
        key: "init",
        value: function init() {
            var context = this,
                $el = context.elem,
                dataSettings = $el.attr('data-hs-file-attach-options') ? JSON.parse($el.attr('data-hs-file-attach-options')) : {},
                options = Object.assign({}, context.defaults, dataSettings, context.settings);
            var $target = $(options.textTarget);
            $el.on('change', function() {
                if ($el.val() === '') {
                    return;
                }

                if (this.files[0].size > options.maxFileSize * 1024) {
                    alert(options.errorMessage);
                    return;
                }

                if (options.mode === 'image') {
                    context._image($el, $target, options);
                } else {
                    context._simple($el, $target);
                }
            });
            $(options.resetTarget).on('click', function() {
                $el.val('');
                $target.attr(options.targetAttr, options.resetImg);
            });
        }
    }, {
        key: "_simple",
        value: function _simple(el, target) {
            target.text(el.val().replace(/.+[\\\/]/, ''));
        }
    }, {
        key: "_image",
        value: function _image(el, target, settings) {
            var reader;

            if (el[0].files && el[0].files[0]) {
                reader = new FileReader();

                reader.onload = function(e) {
                    target.attr(settings.targetAttr, e.target.result);
                };

                reader.readAsDataURL(el[0].files[0]);
            }
        }
    }]);

    return HSFileAttach;
}();