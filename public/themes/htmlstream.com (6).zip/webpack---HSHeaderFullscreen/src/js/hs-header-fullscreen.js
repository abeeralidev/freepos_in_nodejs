Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}(); // Overlay Effect


var _overlayEffect = __webpack_require__( /*! ./observers/overlay-effect */ "./src/js/observers/overlay-effect.js");

var _overlayEffect2 = _interopRequireDefault(_overlayEffect);

function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var HSHeaderFullscreen = function() {
    function HSHeaderFullscreen(element, config) {
        _classCallCheck(this, HSHeaderFullscreen);

        this.element = element;
        this.defaults = {
            overlayClass: 'fullscreen-overlay',
            sectionsContainerSelector: '.fullscreen-content',
            afterOpen: function afterOpen() {},
            afterClose: function afterClose() {}
        };
        this.config = config;
    }

    _createClass(HSHeaderFullscreen, [{
        key: 'init',
        value: function init() {
            var self = this,
                element = this.element;
            var dataSettings = element.attr('data-hs-header-fullscreen-options') ? JSON.parse(element.attr('data-hs-header-fullscreen-options')) : {};

            this.config = $.extend(true, {}, this.defaults, dataSettings);

            this._bindGlobalEvents();

            if (element.data('HSHeaderFullscreen')) return;

            this.overlay = $('<div class="' + this.config.overlayClass + '"></div>');

            this.element.append(this.overlay);

            this.effect = new _overlayEffect2.default().init(this.element, this.overlay, this.config.afterOpen, this.config.afterClose);

            this._bindEvents();
        }
    }, {
        key: '_bindGlobalEvents',
        value: function _bindGlobalEvents() {
            var _self = this;

            $(window).on('resize.HSHeaderFullscreen', function() {
                if (_self.resizeTimeOutId) clearTimeout(_self.resizeTimeOutId);

                _self.resizeTimeOutId = setTimeout(function() {
                    _self.update();
                }, 50);
            });

            $(document).on('keyup.HSHeaderFullscreen', function(e) {
                if (e.keyCode && e.keyCode === 27) {
                    if (!_self.element) return;

                    _self.hide();
                }
            });
        }
    }, {
        key: '_bindEvents',
        value: function _bindEvents() {
            var _self = this;

            this.invoker = $('[data-target="#' + this.element.attr('id') + '"]');

            if (this.invoker.length) {
                this.invoker.off('click.HSHeaderFullscreen').on('click.HSHeaderFullscreen', function(e) {
                    _self[_self.isShown ? 'hide' : 'show']();

                    e.preventDefault();
                });
            }

            return this;
        }
    }, {
        key: 'update',
        value: function update() {
            if (!this.effect) return false;

            this.effect.update();

            return this;
        }
    }, {
        key: 'show',
        value: function show() {
            if (!this.effect) return false;

            this.effect.show();

            return this;
        }
    }, {
        key: 'hide',
        value: function hide() {
            if (!this.effect) return false;

            this.effect.hide();

            return this;
        }
    }, {
        key: 'isShown',
        get: function get() {
            return this.effect.isShown();
        }
    }, {
        key: 'sections',
        get: function get() {
            return this.element.find(this.config.sectionsContainerSelector);
        }
    }]);

    return HSHeaderFullscreen;
}();

exports.default = HSHeaderFullscreen;