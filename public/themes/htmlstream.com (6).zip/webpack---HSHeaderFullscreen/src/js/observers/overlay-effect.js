Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function() {
    function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
        }
    }
    return function(Constructor, protoProps, staticProps) {
        if (protoProps) defineProperties(Constructor.prototype, protoProps);
        if (staticProps) defineProperties(Constructor, staticProps);
        return Constructor;
    };
}();

function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}

var HSHeaderFullscreenOverlayEffect = function() {
    function HSHeaderFullscreenOverlayEffect() {
        _classCallCheck(this, HSHeaderFullscreenOverlayEffect);

        this._isShown = false;
    }

    _createClass(HSHeaderFullscreenOverlayEffect, [{
        key: 'init',
        value: function init(element, overlay, afterOpen, afterClose) {
            var _self = this;

            this.element = element;
            this.overlay = overlay;
            this.afterOpen = afterOpen;
            this.afterClose = afterClose;

            this.overlay.on("webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend", function(e) {
                if (_self.isShown() && e.originalEvent.propertyName === 'transform') {
                    _self.afterOpen.call(_self.element, _self.overlay);
                } else if (!_self.isShown() && e.originalEvent.propertyName === 'transform') {
                    _self.afterClose.call(_self.element, _self.overlay);
                }

                e.stopPropagation();
                e.preventDefault();
            });

            this.update();

            this.overlay.addClass(this.element.data('overlay-classes'));

            return this;
        }
    }, {
        key: 'destroy',
        value: function destroy() {
            this.overlay.css({
                'width': 'auto',
                'height': 'auto'
            });

            this.element.removeClass('fullscreen-showed');

            return this;
        }
    }, {
        key: 'update',
        value: function update() {
            var $w = $(window),
                $wW = $w.width(),
                $wH = $w.height();

            this.overlay.css({
                width: $wW > $wH ? $wW * 1.5 : $wH * 1.5,
                height: $wW > $wH ? $wW * 1.5 : $wH * 1.5
            });

            return this;
        }
    }, {
        key: 'show',
        value: function show() {
            this.element.addClass('fullscreen-showed');
            this._isShown = true;

            return this;
        }
    }, {
        key: 'hide',
        value: function hide() {
            this.element.removeClass('fullscreen-showed');
            this._isShown = false;

            return this;
        }
    }, {
        key: 'isShown',
        value: function isShown() {
            return this._isShown;
        }
    }]);

    return HSHeaderFullscreenOverlayEffect;
}();

exports.default = HSHeaderFullscreenOverlayEffect;